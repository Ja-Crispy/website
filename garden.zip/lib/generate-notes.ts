export interface Note {
  id: string
  title: string
  category: string
  createdAt: number // 0-1 representing timeline position
  connections: string[]
}

const CATEGORIES = [
  "Machine Learning",
  "Web Development",
  "Data Science",
  "DevOps",
  "Mobile Development",
  "Cloud Computing",
  "Cybersecurity",
  "Blockchain",
  "AI Ethics",
  "System Design",
  "Frontend",
  "Backend",
  "Database",
  "Testing",
  "Architecture",
]

const NOTE_TITLES: Record<string, string[]> = {
  "Machine Learning": [
    "Neural Networks",
    "Deep Learning",
    "TensorFlow Basics",
    "PyTorch Setup",
    "CNN Architecture",
    "RNN Patterns",
    "Transformer Models",
    "BERT Fine-tuning",
    "GPT Applications",
    "Reinforcement Learning",
  ],
  "Web Development": [
    "React Hooks",
    "Next.js SSR",
    "TypeScript Generics",
    "CSS Grid Layout",
    "REST API Design",
    "GraphQL Queries",
    "WebSocket Events",
    "Service Workers",
    "PWA Manifest",
    "Web Components",
  ],
  "Data Science": [
    "Pandas DataFrame",
    "NumPy Arrays",
    "Data Visualization",
    "Statistical Analysis",
    "Feature Engineering",
    "Model Evaluation",
    "A/B Testing",
    "Time Series",
    "Clustering Methods",
    "Regression Analysis",
  ],
  DevOps: [
    "Docker Compose",
    "Kubernetes Pods",
    "CI/CD Pipeline",
    "GitHub Actions",
    "Terraform Modules",
    "Ansible Playbooks",
    "Monitoring Setup",
    "Log Aggregation",
    "Incident Response",
    "SRE Practices",
  ],
  "Mobile Development": [
    "React Native",
    "Flutter Widgets",
    "iOS Swift UI",
    "Android Compose",
    "Mobile Testing",
    "App Store Deploy",
    "Push Notifications",
    "Offline Storage",
    "Mobile Security",
    "Cross-Platform",
  ],
  "Cloud Computing": [
    "AWS Lambda",
    "Azure Functions",
    "GCP Services",
    "Serverless Apps",
    "Cloud Storage",
    "CDN Setup",
    "Auto Scaling",
    "Load Balancing",
    "VPC Networks",
    "IAM Policies",
  ],
  Cybersecurity: [
    "OAuth 2.0",
    "JWT Tokens",
    "XSS Prevention",
    "SQL Injection",
    "HTTPS Setup",
    "Encryption Methods",
    "Security Audit",
    "Penetration Testing",
    "Zero Trust",
    "GDPR Compliance",
  ],
  Blockchain: [
    "Smart Contracts",
    "Solidity Basics",
    "Web3.js Setup",
    "DeFi Protocols",
    "NFT Standards",
    "Consensus Mechanisms",
    "Chain Analytics",
    "Wallet Integration",
    "Gas Optimization",
    "Layer 2 Solutions",
  ],
  "AI Ethics": [
    "Bias Detection",
    "Fairness Metrics",
    "Explainable AI",
    "Privacy Concerns",
    "Responsible AI",
    "AI Governance",
    "Model Transparency",
    "Ethical Guidelines",
    "Human Oversight",
    "Impact Assessment",
  ],
  "System Design": [
    "Microservices",
    "Event Sourcing",
    "CQRS Pattern",
    "Cache Strategies",
    "Message Queues",
    "API Gateway",
    "Service Mesh",
    "Circuit Breaker",
    "Rate Limiting",
    "Distributed Systems",
  ],
  Frontend: [
    "Component Library",
    "State Management",
    "Form Validation",
    "Animation Library",
    "Accessibility",
    "Performance Audit",
    "Bundle Optimization",
    "Code Splitting",
    "SEO Practices",
    "Design System",
  ],
  Backend: [
    "Node.js Patterns",
    "Express Middleware",
    "Database ORM",
    "API Versioning",
    "Error Handling",
    "Logging Strategy",
    "Authentication",
    "Authorization",
    "File Uploads",
    "Background Jobs",
  ],
  Database: [
    "PostgreSQL",
    "MongoDB Queries",
    "Redis Caching",
    "Database Indexes",
    "Query Optimization",
    "Data Migration",
    "Backup Strategy",
    "Replication Setup",
    "Sharding Patterns",
    "Schema Design",
  ],
  Testing: [
    "Unit Testing",
    "Integration Tests",
    "E2E Testing",
    "Test Coverage",
    "Mocking Strategies",
    "Test Automation",
    "Performance Testing",
    "Security Testing",
    "Visual Regression",
    "Contract Testing",
  ],
  Architecture: [
    "Clean Architecture",
    "Domain Driven",
    "Hexagonal Pattern",
    "Event Driven",
    "Layered Architecture",
    "Modular Monolith",
    "Saga Pattern",
    "Outbox Pattern",
    "Anti-Corruption Layer",
    "Bounded Context",
  ],
}

function seededRandom(seed: number) {
  const x = Math.sin(seed++) * 10000
  return x - Math.floor(x)
}

export function generateNotes(count: number): Note[] {
  const notes: Note[] = []
  let seed = 42

  for (let i = 0; i < count; i++) {
    const categoryIndex = Math.floor(seededRandom(seed++) * CATEGORIES.length)
    const category = CATEGORIES[categoryIndex]
    const titles = NOTE_TITLES[category]
    const titleIndex = Math.floor(seededRandom(seed++) * titles.length)

    // Spread notes across the timeline with some clustering
    const baseTime = seededRandom(seed++)
    const cluster = Math.floor(seededRandom(seed++) * 5) * 0.15
    const createdAt = Math.min(0.95, Math.max(0.05, baseTime * 0.7 + cluster))

    const note: Note = {
      id: `note-${i}`,
      title: titles[titleIndex],
      category,
      createdAt,
      connections: [],
    }

    // Add some connections to previous notes
    if (notes.length > 0) {
      const numConnections = Math.floor(seededRandom(seed++) * 3)
      for (let j = 0; j < numConnections && j < notes.length; j++) {
        const connectionIndex = Math.floor(seededRandom(seed++) * notes.length)
        if (!note.connections.includes(notes[connectionIndex].id)) {
          note.connections.push(notes[connectionIndex].id)
        }
      }
    }

    notes.push(note)
  }

  return notes
}
